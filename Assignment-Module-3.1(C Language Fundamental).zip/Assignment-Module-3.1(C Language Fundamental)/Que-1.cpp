#include<stdio.h>
int main()
{
	printf("Name:Disha jasani \nBirth Date:31-07-2002 \nAge:20 \nAddress:Abc house, xx street, rajkot.");
}
