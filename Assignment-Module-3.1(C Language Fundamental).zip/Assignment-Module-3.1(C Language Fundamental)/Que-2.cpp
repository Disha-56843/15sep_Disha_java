#include<stdio.h>
int main()
{
	int a,b;
	a=15;
	b=12;
	printf("Addition of a and b is :%d",a+b);
	printf("\nSubstraction of a and b is :%d",a-b);
	printf("\nMultiplication of a and b is :%d",a*b);
	printf("\nDivission of a and b is :%d",a/b);
	printf("\nModulo of a and b is :%d",a%b);
}
