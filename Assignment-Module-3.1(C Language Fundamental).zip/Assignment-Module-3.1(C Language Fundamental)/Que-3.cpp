#include<stdio.h>
int main()
{
	float pi,r,l,w,h,b;
	pi=3.14;
	r=4;
	l=5;
	w=3;
	h=7;
	b=8;
	printf("Area of circle is:%f",pi*r*r);
	printf("\nArea of rectangle is:%f",w*l);
	printf("\nArea of triangle is:%f",h*b/2);
}
